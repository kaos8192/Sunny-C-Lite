#include "node.h"
#include "gAll.h"
#include "symtab.h"
#include "opcodes.h"
#include "helper.h"
#include <iostream>
#include <vector>

using namespace std;

Node::Node(string name) : m_token(name)
{}

string Node::token() const
{
	return m_token;
}

void Node::set_token(const string& name)
{
	m_token = name;
}

void Node::visit(int depth) const
{
	for (int i=0; i < depth; ++i) {
		cout << "  ";
	}
	cout << m_token << endl;
	for (auto n: m_children) {
		n->visit(depth+1);
	}
}

void Node::add_child(Node* const kid)
{
	m_children.push_back(kid);
}

Constant::Constant(string name) : Node(name)
{}

int Constant::value() const
{
	return m_value;
}

void Constant::set_value(const int v) 
{
	m_value = v;
}

void Constant::visit(int depth) const
{
	for (int i=0; i < depth; ++i) {
		cout << "  ";
	}
	cout << m_token << "(" << m_value << ")" << endl;
	for (auto n: m_children) {
		n->visit(depth+1);
	}
}

Identifier::Identifier(string name) : Node(name)
{}

string Identifier::value() const
{
	return m_value;
}

void Identifier::set_value(const string& v) {
	m_value = v;
}

void Identifier::visit(int depth) const
{
	for (int i=0; i < depth; ++i) {
		cout << "  ";
	}
	cout << m_token << "(" << m_value << ")" << endl;
	for (auto n: m_children) {
		n->visit(depth+1);
	}
}
//help
int Node::generate_code(){
	if(m_token == "start"){
        jsr_abs(0xe544);
		if(m_children.size() == 1){
			m_children[0]->generate_code();

		}else{
			//error
		}
        rts();
    }else if(m_token == "starta"){
		if(m_children.size() == 1){
			m_children[0]->generate_code();
		}else if(m_children.size() == 2){
			m_children[0]->generate_code();
			m_children[1]->generate_code();
		}else{
			//error
		}

	}else if(m_token == "stmt"){
		if(m_children.size() == 1){
			m_children[0]->generate_code();
		}else{
			//error
		}
	}else if(m_token == "shape"){
        if(m_children.size() == 2){
            int x = m_children[0]->generate_code();
            int y = m_children[1]->generate_code();
            make_point(x,y);
        }else if(m_children.size() == 6){
            m_children[0]->generate_code();
            m_children[1]->generate_code();
            m_children[2]->generate_code();           
            m_children[3]->generate_code();
            m_children[4]->generate_code();
            m_children[5]->generate_code();
        }else{
            //error
        }
	}else if(m_token == "expr"){
        if(m_children.size() == 1){
            m_children[0]->generate_code();
        }else{
            //error
        }
	}else if(m_token == "postant"){
        if(m_children.size() == 0){
            Constant* c = dynamic_cast<Constant*>(this);
            if(c == NULL){
                //error
            }
            else{
                int c_val = c->value();
                int temp_c = slap.temporary();
                lda_imm(low(c_val));
                sta_abs(slap.address(temp_c));
                lda_imm(high(c_val));
                sta_abs(slap.address(temp_c)+1);
                return temp_c;
            }
        }else{
            //error
        }
    }else if(m_token == "value"){
        if(m_children.size() == 1){
            return m_children[0]->generate_code();
    
        }else{
            //error
        }
    }else if(m_token == "identifier"){
        if(m_children.size() == 0){
            Identifier* i = dynamic_cast<Identifier*>(this);
            if(i == NULL){
            }
            else if(slap.address_of(i->value()) != -1){
                //cerr << i->value() << " : FOUND" << endl;
                return slap.id_of(i->value());
            }
            else{
                //cerr << i->value() << " : NEW" << endl;
                string i_val = i->value();
                int temp_i = slap.add(i_val);
                return temp_i;
            }
        }else{
            //error
        }
	}else if(m_token == "iter"){
        if(m_children.size() == 3){
            m_children[0]->generate_code();
            m_children[1]->generate_code();
            m_children[2]->generate_code();
        }else{
            //error
        }
	}else if(m_token == "jump"){
        if(m_children.size() == 0){
            //TODO
        }else{
            //error
        }
	}else if(m_token == "jumpstart"){
        if(m_children.size() == 0){
            //TODO
        }else{
            //error
        }
	}else if(m_token == "jumpend"){
        if(m_children.size() == 0){
            //TODO
        }else{
            //error
        }
	}else if(m_token == "select"){
        if(m_children.size() == 2){
            m_children[0]->generate_code();
            m_children[1]->generate_code();
        }else if(m_children.size() == 3){
            m_children[0]->generate_code();
            m_children[1]->generate_code();
            m_children[2]->generate_code();
        }else{
            //error
        }
	}else if(m_token == "assignment"){
		if(m_children.size() == 2){
            int id = m_children[0]->generate_code();
            int from = m_children[1]->generate_code();
            lda_abs(slap.address(from));
            sta_abs(slap.address(id));
            lda_abs(slap.address(from)+1);
            sta_abs(slap.address(id)+1);
        }else{
            //error
        }
	}else if(m_token == "bool"){
		if(m_children.size() == 1){
            int a = m_children[0]->generate_code();
            return a;
        }else{
            //error
        }
	}else if(m_token == "not"){
		if(m_children.size() == 1){
            m_children[0]->generate_code();
            return 0;
        }else{
            //error
        }
	}else if(m_token == "or"){
        if(m_children.size() == 2){
            m_children[0]->generate_code();
            m_children[1]->generate_code();
            return 0;
        }else{
            //error
        }
	}else if(m_token == "and"){
        if(m_children.size() == 2){
            m_children[0]->generate_code();
            m_children[1]->generate_code();
            return 0;
        }else{
            //error
        }

	}else if(m_token == "compa"){
		if(m_children.size() == 1){
            int a = m_children[0]->generate_code();
            return a;
        }else{
            //error
        }
	}else if(m_token == "eq"){
		if(m_children.size() == 2){
            int l = m_children[0]->generate_code();
            int r = m_children[1]->generate_code();
            clc();
            //lda_abbs(slap.address(l));
            return 0;
        }else{
            //error
        }
	}else if(m_token == "gt"){
		if(m_children.size() == 2){
            int l = m_children[0]->generate_code();
            int r = m_children[1]->generate_code();
            clc();
            return 0;
        }else{
            //error
        }
	}else if(m_token == "lt"){
		if(m_children.size() == 2){
            int l = m_children[0]->generate_code();
            int r = m_children[1]->generate_code();
            clc();
            return 0;
        }else{
            //error
        }

	}else if(m_token == "arith"){
		if(m_children.size() == 1){
            m_children[0]->generate_code();
        }else if(m_children.size() == 2){
            m_children[0]->generate_code();
            m_children[1]->generate_code();
        }else{
            //error
        }
	}else{
		//error
	}
    return 1;
}
