CMSC 445 Fall 2019 Lab3
Geir Anderson and Alex Sedgwick

Implemented features:
	Point(Works!)
	If statements(Do not work)
	Loops(Do not work)
	Identifiers and Constants (Works!)
	Addition and Subtraction
	
To compile:
	gencompile

To run a test program:
	Print to the screen:
	./exampleland < (name of language file)
	Should print out assembly code

	./test_prog.sh (name of language file)
	Will be run on the Commadore emulator

Who did what:
	Geir-

	Alex- Made the point*.lang files, gencompile,  and helped out with a variety of other tasks.
